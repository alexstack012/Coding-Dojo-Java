public class BasicsTest {
    public static void main(String[] args) {
        Basics basic = new Basics();
        // basic.counting();
        // basic.countingSum();
        // basic.arrayLoop();
        // basic.max();
        basic.countingOdd();
    }

}