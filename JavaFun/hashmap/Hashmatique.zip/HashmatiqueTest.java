public class HashmatiqueTest {
    public static void main(String[] args) {
        Hashmatique hash = new Hashmatique();
        hash.Challange();
    }

}