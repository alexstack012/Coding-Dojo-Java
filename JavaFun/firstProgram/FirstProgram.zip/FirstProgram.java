public class FirstProgram {
    public static void main(String[] args) {
        System.out.println("My Name is Alex Stack");
        System.out.println("I am 28 years old");
        System.out.println("From Lakeville Minnesota!");
    }
}