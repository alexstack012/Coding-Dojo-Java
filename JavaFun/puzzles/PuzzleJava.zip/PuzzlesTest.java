public class PuzzlesTest {
    public static void main(String[] args) {
        PuzzleJava puzzles = new PuzzleJava();
        // System.out.println(puzzles.getTenRolls());
        // System.out.println(puzzles.getRandomLetterWithArray());
        // System.out.println(puzzles.generatePassword());
    }
}