public class ExceptionsTest {
    public static void main(String[] args) {
        Exceptions exception = new Exceptions();
        exception.Exceptions();
    }

}