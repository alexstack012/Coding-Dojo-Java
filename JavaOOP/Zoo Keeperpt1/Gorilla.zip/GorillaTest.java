public class GorillaTest{
    public static void main(String args[]){
        Gorilla g = new Gorilla();

        g.throwSomething();
        g.throwSomething();
        g.throwSomething();
        g.eatBananas();
        g.eatBananas();
        g.climb();
        g.displayEnergy();
    }
}