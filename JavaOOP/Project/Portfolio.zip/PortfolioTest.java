class PortfolioTest{
    public static void main(String[] args){
        Portfolio port1 = new Portfolio();
        Portfolio port2 = new Portfolio();

        port1.AddToPortfolio("Stuff");
        port2.AddToPortfolio("Things", "Theres Stuff! and Things!!" );


    }
}