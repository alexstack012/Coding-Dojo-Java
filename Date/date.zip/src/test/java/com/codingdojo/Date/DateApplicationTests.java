package com.codingdojo.Date;

import org.junit.jupiter.api.Test;
import org.springframework.boot.test.context.SpringBootTest;

@SpringBootTest
class DateApplicationTests {

	@Test
	void contextLoads() {
	}

}
