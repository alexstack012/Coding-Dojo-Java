package com.codingdojo.mvc.dojosNinjas;

import org.junit.jupiter.api.Test;
import org.springframework.boot.test.context.SpringBootTest;

@SpringBootTest
class ProductsApplicationTests {

	@Test
	void contextLoads() {
	}

}
